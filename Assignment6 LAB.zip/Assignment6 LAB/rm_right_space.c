#include <stdio.h>
#include "assign6lib.h"

void rm_right_space(char *s) {
    int last;
    int i = 0;
    while(s[i] != '\0') {
        if (s[i] != ' ' && s[i] != '\t' && s[i] != '\n') {
            last = i;
        }
        i++;
    }
    s[last + 1] = '\0';
}