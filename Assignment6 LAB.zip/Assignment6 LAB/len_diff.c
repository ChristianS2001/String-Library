#include <stdio.h>
#include "assign6lib.h"

int len_diff(char *s1, char *s2) {
    return (str_len(s1) - str_len(s2));
}