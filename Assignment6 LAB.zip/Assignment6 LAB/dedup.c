#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

char* dedup(char *s)
{
   int hash[256] = {0};
   int i = 0, j = 0;
  
   while(s[i] != '\0')
   {
       i += 1;
   }

   char *p = (char *)malloc(sizeof(char)*i);
   i = 0;
  
   while(s[i] != '\0')
   {
       hash[s[i]] += 1;
       if(hash[s[i]] == 1)
       {
           p[j] = s[i];
           j += 1;
       }
       i += 1;
   }
   p[j] = '\0';
   return p;
}