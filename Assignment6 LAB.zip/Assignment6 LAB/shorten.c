#include <stdio.h>
#include "assign6lib.h"

void shorten(char *s, int new_len) {
    if (new_len < str_len(s)) {
        s[new_len] = '\0';
    }
}