#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

void copy(char *dest, char *src, int size) {
    int i = 0;
    for(i = 0; i < size; i++) {
        dest[i] = src[i];
    }
    dest[i] = '\0';
}