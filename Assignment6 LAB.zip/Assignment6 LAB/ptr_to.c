#include <stdio.h>
#include "assign6lib.h"

char *ptr_to(char *h, char *n) {
    char *t = h;
    while (*t != '\0') {
        if (*t == *n) {
            return t;
        }
        t++;
    }
    return NULL;
}