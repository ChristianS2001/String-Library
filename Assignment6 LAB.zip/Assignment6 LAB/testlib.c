#include "assign6lib.h"
#include <stdio.h>

int main (int argc, char **argv) {
    char *test = "chris";
    char *test1 = "Chris";
    char *test2 = "Chris0";
    char *test3 = "abcdefghijklmnopqrstuvwxyz";
    char *test4 = "Christian";
    char *test5 = "all right";
    char shortenTest[] = "Christian";
    char rmLeftSpaceTest[] = " Hello";
    char rmRightSpaceTest[] = "Hello ";
    char rmRightSpaceTest2[] = "Hello World  ";
    char rmSpaceTest[] = " Hello World ";
    char *findTest = "Whats Up!";
    char *findTestCharacter = "!";
    char *isEmptyTest1 = "";
    char *isEmptyTest2 = "   ";
    char *isEmptyTest3 = NULL;
    char *zip1 = "Spongebob";
    char *zip2 = "Patrick";
    char capTest[] = "these should be capitalized, aLSo thiS shOUlD bE fiXED.";
    char ab[] = "ab";
    char bc[] = "bc";
    char takeTest[] = "Pepperoni";
    char *dedupTest = "There's always money in the banana stand.";
    char *stuff = "banana stand.";
    char *connectTest1[] = {"Washingtown", "Adams", "Jefferson"};
    char *rightEmptiesTest[] = {"Washington", "Adams", "", "Jefferson", NULL};


    printf("str_len(chris) = %i\n", str_len(test));

    printf("all_letters(Chris) = %i\n", all_letters(test1));
    printf("all_letters(Chris0) = %i\n", all_letters(test2));

    printf("num_in_range(Chris, C, s) = %i\n", num_in_range(test1, 'C', 's'));
    printf("num_in_range(alphabet, a, q) = %i\n", num_in_range(test3, 'a', 'q'));

    printf("diff(Chris, alphabet) = %i\n", diff(test1, test3));
    printf("diff(Chris, Christian) = %i\n", diff(test1, test4));

    shorten(shortenTest, 5);
    printf("shorten(Christian, 5) = %s\n", shortenTest);

    printf("len_diff(Christian, Chris) = %i\n", len_diff(test4, test1));
    printf("len_diff(Chris, Christian) = %i\n", len_diff(test1, test4));

    rm_left_space(rmLeftSpaceTest);
    printf("rm_left_space(rmLeftSpaceTest) = '%s'\n", rmLeftSpaceTest);
    rm_right_space(rmRightSpaceTest);
    printf("rm_right_space(rmRightSpaceTest) = '%s'\n", rmRightSpaceTest);
    rm_right_space(rmRightSpaceTest2);
    printf("rm_right_space(rmRightSpaceTest2) = '%s'\n", rmRightSpaceTest2);

    rm_space(rmSpaceTest);
    printf("rm_space(rmSpaceTest) = '%s'\n", rmSpaceTest);

    printf("find(Whats Up!, '!') = %i\n", find(findTest, findTestCharacter));

    printf("*ptr_to(Whats Up!, '!' = %p\n", ptr_to(findTest, findTestCharacter));

    printf("is_empty('') = %i\n", is_empty(isEmptyTest1));
    printf("is_empty('    ') = %i\n", is_empty(isEmptyTest2));
    printf("is_empty(NULL) = %i\n", is_empty(isEmptyTest3));

    printf("str_zip(zip1, zip2) = %s\n", str_zip(zip1, zip2)); 

    capitalize(capTest);
    printf("capitalize(these should be capitalized, aLSo thiS shOUlD bE fiXED.) = %s\n", capTest);

    printf("strcmp_ign_case(ab, bc) = %i\n", strcmp_ign_case(ab, bc));

    take_last(takeTest, 4);
    printf("take_last(takeTest, 4) = %s\n", takeTest);

    printf("dedup(dedupTest) = %s\n", dedup(dedupTest));
    
    printf("pad(dedupTest, 8) = %s\n", pad(dedupTest, 8));

    printf("ends_with_ignore(dedupTest, 'bannana stand' = %i\n", ends_with_ignore_case(dedupTest, stuff));

    printf("repeat(test5, 3, ',') = %s\n", repeat(test5, 3, ','));

    printf("replace('chicken X, X, nugget) = %s\n", replace("chicken X", "X", "nugget"));

    printf("str_connect(connectTest1, 3, '+') = %s\n", str_connect(connectTest1, 3, '+'));

    rm_empties(rightEmptiesTest);
}