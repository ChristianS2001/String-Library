#include <stdio.h>
#include "assign6lib.h"

int is_empty(char *s) {
    int i = 0;
    if (s == NULL){
        return 1;
    } else if(s[0] == '\0') {
        return 1;
    } else {
        while (s[i] != '\0') {
            if (s[i] != ' ' && s[i] != '\t' && s[i] != '\n') {
                return 0;
            }
            i++;
        }
        return 1;
    }
}