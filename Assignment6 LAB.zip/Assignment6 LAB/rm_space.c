#include <stdio.h>
#include "assign6lib.h"

void rm_space(char *s) {
    rm_left_space(s);
    rm_right_space(s);
}