#include <stdio.h>
#include "assign6lib.h"

void rm_left_space(char *s) {
    int count = 0;
    while (s[count] == ' ' || s[count] == '\t' || s[count] == '\n') {
        count++;
    }
    if(count != 0) {
        int i = 0;
        while(s[i + count] != '\0') {
            s[i] = s[i + count];
            i++;
        }
        s[i] = '\0';
    }
}