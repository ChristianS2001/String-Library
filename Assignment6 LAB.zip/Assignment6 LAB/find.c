#include <stdio.h>
#include "assign6lib.h"

int find(char *h, char *n) {
    int i = 0;
    while (h[i] != '\0') {
        if (h[i] == *n) {
            return i;
        }
        i++;
    }
    return -1;

}