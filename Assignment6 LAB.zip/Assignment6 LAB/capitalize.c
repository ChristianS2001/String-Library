#include <stdio.h>
#include "assign6lib.h"

void capitalize(char *s) {
    int i = 0;
    for(i = 0; s[i] != '\0'; i++) {
        if(i==0) {
            if((s[i] >= 'a' && s[i] <= 'z')) {
                s[i] = s[i] - 32; //this makes it capital
                continue; //continue the loop
            }
        }
        if (s[i] == ' ') { //check for space
            ++i; //if space is found check the next character
            if((s[i] >= 'a' && s[i] <= 'z')) {
                s[i] = s[i] - 32;
                continue;
            }
        }
        else {
            //turn all other uppercases into lowercase
            if(s[i] >= 'A' && s[i] <= 'Z') {
                s[i] = s[i] + 32; //to turn character into uppercase
            }
        }
    }
}