#include <stdio.h>
#include "assign6lib.h"

int all_letters(char *s) {
    char *t = s;
    while (*t != '\0') {
        if (!(*t >= 'a' && *t <= 'z' || *t >= 'A' && *t <= 'Z')) {
            return 0;
        }
        t++;
    }
    return 1;
}