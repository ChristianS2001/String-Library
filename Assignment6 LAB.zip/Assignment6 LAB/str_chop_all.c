#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

char **str_chop_all(char *s, char c) {
        int num = 0;
        int i = 0;
        while(s[i] != '\0') {
                if(s[i] == c) {
                        num++;
                }
                i++;
        }

        char **result = malloc(sizeof(char *) * (2 + num));
        int start = 0, len = 0;
        int count = 0;
        i=0;

        while(s[i] != '\0') {
                if(s[i] == c) {
                        result[count] = malloc(sizeof(char) * (len + 1));
                        copy(result[count], s+start, len);
                        start = i + 1;
                        len = 0;
                        count++;
                } else {
                        len++;
                }
                i++;
        }
        if(start != i) {
                result[count] = malloc(sizeof(char) * (len + 1));
                copy(result[count], s+start, len);
                count++;
        }
        result[count] = NULL;
        return result;
}