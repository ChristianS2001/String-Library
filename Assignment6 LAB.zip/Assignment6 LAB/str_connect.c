#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

char *str_connect(char **strs, int n, char c)
{
    int i, j, length = 0, k = 0;
    for (i = 0; i < n; i++)
    {

        for (j = 0; strs[i][j] != '\0'; j++)
            ;
        length += j;
    }
    char *newStr = (char *)malloc(sizeof(c) * (length + n));
    for (i = 0; i < n; i++)
    {
        for (j = 0; strs[i][j] != '\0'; j++)
        {
            newStr[k++] = strs[i][j];
        }
        newStr[k++] = c;
    }

    newStr[k - 1] = '\0';
    return newStr;
}