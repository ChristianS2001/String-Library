#include <stdio.h>
#include "assign6lib.h"
#include <ctype.h>

int strcmp_ign_case(char *s1, char *s2) {
    int i = 0;
    int diff = 0;
    for (i = 0; s1[i] != '\0'; i++) {
        if (toupper(s1[i]) != toupper(s2[i])) {
            diff += s1[i] - s2[i];
        }
    }
    if (diff == 0) {
        return 0;
    }
    else if (diff > 0) {
        return -1;
    }
    else {
        return 1;
    }
}