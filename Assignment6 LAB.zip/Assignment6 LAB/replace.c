#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

char *replace(char *s, char *pat, char *rep)
{
    int len_rep, len_pat, len_s;
    int i, j, k = 0, flag, count = 0;
    for (len_s = 0; s[len_s] != '\0'; len_s++);
    for (len_pat = 0; pat[len_pat] != '\0'; len_pat++);
    for (len_rep = 0; rep[len_rep] != '\0'; len_rep++);
    for (i = 0; i < len_s; i++)
    {
        for (j = 0; j < len_pat; j++)
        {
            if (pat[j] != s[i + j])
            {
                break;
            }
        }
        if (j == len_pat)
            count++;
    }
    char *newString = (char *)malloc(sizeof(s) * (len_s + count * len_rep - count * len_pat));
    for (i = 0; i < len_s; i++)
    {
        newString[k++] = s[i];
        flag = 1;
        for (j = 0; j < len_pat; j++)
        {
            if (pat[j] != s[i + j])
            {
                flag = 0;
            }
        }
        if (flag)
        {
            k -= 1;
            for (j = 0; j < len_rep; j++)
            {
                newString[k++] = rep[j];
            }
            i = i + len_pat - 1;
        }
    }
    newString[k] = '\0';
    return newString;
}