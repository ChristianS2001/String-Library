#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

char *str_zip(char *s1, char *s2) {

    //char new[100];
    int i = 0;
    char* new = malloc(str_len(s1) + str_len(s2) + 1);
    char *temp = new;
    if (new == NULL) {
        return NULL;
    }
    while(*s1 != '\0' && *s2 != '\0') {
        if (i % 2 == 0) {
            i++;
            *temp++ = *s1++;
        } else {
            i++;
            *temp++ = *s2++;
        }
    }
    while(*s1 != '\0') {
        *temp++ = *s1++;
    }
    while(*s2 != '\0') {
        *temp++ = *s2++;
    }
    *temp = '\0';
    return new; 
}