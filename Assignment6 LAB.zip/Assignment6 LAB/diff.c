#include <stdio.h>
#include "assign6lib.h"

int diff(char *s1, char *s2) {
    int i = 0;
    int count = 0;
    if (str_len(s1) == str_len(s2)) {
        while (s1[i] != '\0') {
            if (s1[i] != s2[i]) {
                count++;
            }
            i++;
        }
        return count;
    }
    else if (str_len(s1) > str_len(s2)) {
        while (s2[i] != '\0') {
            if (s1[i] != s2[i]) {
                count++;
            }
            i++;
        }
        return count + (str_len(s1) - str_len(s2));
    }
    else {
        while (s1[i] != '\0') {
            if(s2[i] != s1[i]) {
                count++;
            }
            i++;
        }
    }
    return count + (str_len(s2) - str_len(s1));
}