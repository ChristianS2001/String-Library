#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

int ends_with_ignore_case(char *s, char *suff)
{
   int len1 = 0, len2 = 0;
   while(s[len1] != '\0')
       len1 += 1;
      
   while(suff[len2] != '\0')
       len2 += 1;
  
   if(len2 > len1)
       return 0;
  
   len2 -= 1;
   len1 -= 1;

   while(len2 >= 0)
   {
       if((s[len1]>='a' && s[len1]<='z') && (suff[len2]>='A' && suff[len2]<='Z'))
       {
           if( (char)(s[len1]-32) != suff[len2])
               return 0;
       }
       else if((s[len1]>='A' && s[len1]<='Z') && (suff[len2]>='a' && suff[len2]<='z'))
       {
           if( (char)(suff[len2]-32) != s[len1])
               return 0;
       }
       else
       {
           if(s[len1] != suff[len2])
               return 0;
       }
       len1 -= 1;
       len2 -= 1;
   }
   return 1;
}