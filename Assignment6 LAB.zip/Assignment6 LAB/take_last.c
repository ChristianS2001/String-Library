#include <stdio.h>
#include "assign6lib.h"

void take_last(char *s, int n) {
    int i = 0;
    int j = 0;
    if (n < str_len(s)) {
        for (i = (str_len(s) - n); i < str_len(s); i++) {
            s[j++] = s[i];
        }
        s[j] = '\0';
    }
}