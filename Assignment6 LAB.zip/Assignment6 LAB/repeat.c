#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

char *repeat(char *s, int x, char sep)
{
    int i = 0;
    int j = 0;
    int n = 0;
    int k = 0;
    for (n = 0; s[n] != '\0'; n++);
    char *newString = (char *)malloc(sizeof(s) * (n * x + x));
    for (i = 0; i < x; i++)
    {
        for (j = 0; j < n; j++)
        {
            newString[k++] = s[j];
        }
        newString[k++] = sep;
    }
    newString[k - 1] = '\0';
    return newString;
}