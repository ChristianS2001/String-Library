#include <stdio.h>
#include "assign6lib.h"
#include <stdlib.h>

char *pad(char *s, int d)
{
   if(s == NULL)
       return NULL;
  
   int i = 0;
   while(s[i] != '\0')
       i += 1;
  
   if(i % d == 0)
       return s;
  
   int dev = i/d;
   d = d*(dev+1);
  
   char *result = (char *)malloc(sizeof(char)*d);
   i = 0;
   while(s[i] != '\0')
   {
       result[i] = s[i];
       i += 1;
   }
   while(i < d)
   {
       result[i] = ' ';
       i += 1;
   }
   result[d] = '\0';
   return result;
}